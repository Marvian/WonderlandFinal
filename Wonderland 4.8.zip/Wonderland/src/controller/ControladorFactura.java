/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.Usuario;
import model.Facturacion;

/**
 *
 * @author Jessica
 */
public class ControladorFactura {
    
        public static void llenaTablaFactura(JTable tablaFactura, FacturaXML DatMet, Usuario usuario, DefaultTableModel dtm) {
        ArrayList<Facturacion> Lista = DatMet.todosLasFacturas();
        for (Facturacion est : Lista) {
            if (est.getCi().equals(usuario.getCedula())) {
                String[] row = {est.getNombre(), est.getPrecio(), est.getCantidadpro(), est.getProveedor(),est.getTotal(),est.getCi()};
                dtm.addRow(row);
            }
        }
        tablaFactura.setModel(dtm);
    }
}
