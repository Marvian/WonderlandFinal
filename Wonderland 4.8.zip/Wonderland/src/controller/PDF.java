/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

/**
 *
 * @author essteeli
 */
//librerias iText
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
//archivos
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
//librerias ajenas a iText
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import view.DatosFactura;

public class PDF {
    //Destino donde se guardará el documento
    private File destino = null;

    public PDF() {
    }

    public void Destino() {
        //Filtro: solo extensión pdf
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivo PDF", "pdf", "PDF");
        //Creamos un FileChooser
        JFileChooser fileChooser = new JFileChooser();
        //Le agregamos el filtro al FileChooser
        fileChooser.setFileFilter(filter);
        int result = fileChooser.showSaveDialog(null);
        /*Si es aprovado, es decir, se se presiona 'Guardar' entonces
        se obtiene la ruta absoluta del directorio al que hace referencia el actual archivo*/
        if (result == JFileChooser.APPROVE_OPTION) {
            this.destino = fileChooser.getSelectedFile().getAbsoluteFile();
        }
    }


    public void crear(String titulo, String autor, String asunto, String palabraClave, String contenido) {
        //abre ventana de dialogo "guardar"
        Destino();
        //si destino es diferente de null
        if (this.destino != null) {
            try {
                // se crea instancia del documento
                Document mipdf = new Document();
                // se establece una instancia a un documento pdf
                PdfWriter.getInstance(mipdf, new FileOutputStream(this.destino + ".pdf"));
                mipdf.open();// se abre el documento
                mipdf.addTitle(titulo); // se añade el titulo
                mipdf.addAuthor(autor); // se añade el autor del documento
                mipdf.addSubject(asunto); //se añade el asunto del documento
                mipdf.addKeywords(palabraClave); //Se agregan palabras claves
                mipdf.add(new Paragraph(contenido)); // se añade el contendio del PDF
                mipdf.close(); //se cierra el PDF&
                JOptionPane.showMessageDialog(null, "Documento PDF creado");
            } catch (DocumentException ex) {
                Logger.getLogger(DatosFactura.class.getName()).log(Level.SEVERE, null, ex);
             } catch (FileNotFoundException ex) {
                Logger.getLogger(DatosFactura.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
/*================================================================================*/
/*================================================================================*/